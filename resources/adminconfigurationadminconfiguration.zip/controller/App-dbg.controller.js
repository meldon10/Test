sap.ui.define([
	"adminconfiguration/adminconfiguration/controller/BaseController"
], 
    /**
     * @param {typeof com.sap.acs.ui.dashboard.controller.BaseController} BaseController 
     */
    function (BaseController) {
        "use strict";
        return BaseController.extend("adminconfiguration.adminconfiguration.controller.App", {
            onInit: function () {
            }
    });
});